# ROTUL'S AI ULTRA — Android APK project

Project ini membungkus versi web ROTUL'S AI ULTRA menjadi aplikasi Android memakai Capacitor.

## Cara membuat APK (perlu Mac/Windows/Linux dengan Android Studio + Android SDK)

1. Install Node.js LTS dan Android Studio.
2. Ekstrak ZIP ini.
3. Buka Terminal di folder `rotuls-ai-ultra-android`.
4. Jalankan:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

5. Di Android Studio, tunggu Gradle sync selesai.
6. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
7. Setelah selesai, klik **locate** pada notifikasi build. APK biasanya ada di `android/app/build/outputs/apk/debug/app-debug.apk`.

Untuk APK rilis: **Build > Generate Signed Bundle / APK...** lalu buat keystore sendiri dan simpan dengan aman.

## Penting
- Ini project sumber siap-build, bukan APK yang sudah dikompilasi. Lingkungan pembuat ZIP ini tidak memiliki Android SDK/Gradle Android yang diperlukan untuk menghasilkan APK final.
- API key OpenRouter yang dimasukkan di Pengaturan versi web disimpan di localStorage pada perangkat. Jangan membagikan APK yang berisi API key pribadi. Untuk aplikasi publik, gunakan backend agar API key tidak tersimpan di aplikasi klien.
- Fitur tertentu seperti image generation bergantung pada model/API yang benar-benar mendukung output gambar.


## Desain neon dan logo R
Versi ini memakai logo R neon yang dipilih pengguna di `www/assets/rotuls-r-logo.jpg`, splash screen awal, navigasi bawah khusus HP, dan tema gelap neon. File `resources-icon.png` dan `resources-splash.png` disediakan sebagai sumber ikon/splash native.

Untuk membuat ikon launcher native sebelum build Android, setelah `npm install` jalankan:
```bash
npm install -D @capacitor/assets
npx capacitor-assets generate --iconBackgroundColor '#030719' --iconBackgroundColorDark '#030719' --splashBackgroundColor '#030719' --splashBackgroundColorDark '#030719'
```
Tempatkan/rename `resources-icon.png` menjadi `resources/icon.png` dan `resources-splash.png` menjadi `resources/splash.png` sebelum perintah tersebut.
